package Aspirador;

import java.util.Arrays;
import java.util.List;
//Classe para pegar os estados objetivos do problema para verificacao
public class Objectives {
    //Dois estados onde o primeiro indica que o aspirador esta na sala 1 e todos os compartimentos estao limpos e o segundo que o aspirador esta
    //na sala 2 e todos os compartimentos estao limpos.
	private int[] objectiveState1 = {1,0,0}, objectiveState2 = {2,0,0};


    public int[] getObjectiveState1() {
        return objectiveState1;
    }

    public void setObjectiveState1(int[] objectiveState1) {
        this.objectiveState1 = objectiveState1;
    }

    public int[] getObjectiveState2() {
        return objectiveState2;
    }

    public void setObjectiveState2(int[] objectiveState2) {
        this.objectiveState2 = objectiveState2;
    }

}
