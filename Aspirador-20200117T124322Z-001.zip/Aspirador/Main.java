package Aspirador;

import java.util.List;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;

public class Main {

	public static void main(String[] args) {
		long tempoInicial = System.currentTimeMillis();
		Random gerador = new Random();
		List<Integer> nomes = new ArrayList<>();
		
		Problem pro = new Problem(gerador.nextInt(8));
		
		Search busca = new Search();
		nomes = busca.buscaBidirecional(pro);
		long tempoFinal = System.currentTimeMillis();
		System.out.printf("Tempo de execucao em ms\n");
		System.out.println(tempoFinal-tempoInicial);
		
		/*//mostra as solu��o
		if(nomes != null) {
			System.out.println("Solu��o:");
			for(int i = 0;i<nomes.size();i++) {
				System.out.printf("\nA��o %d", nomes.get(i));
			}
		}*/
	}

}
