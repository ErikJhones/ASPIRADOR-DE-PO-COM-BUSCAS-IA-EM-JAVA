package Aspirador;

public class Node {
	private int[] state;
    private Integer action;
    private int cost, value;
    private Node dad;

    public Node(int[] state, Node dad, Integer action, int cost, int value){
        this.state = state;
        this.dad = dad;
        this.action = action;
        this.cost = cost; //valor do custo desde o pai at� ele.
        this.value = value;
    }

//    Setar ou pegar os valores de cada variável.
    public int[] getState() {
        return state;
    }

    public void setState(int[] state) {
        this.state = state;
    }

    public int getAction() {
        return action;
    }

    public void setAction(int action) {
        this.action = action;
    }

    public int getCost() {
        return cost;
    }

    public void setCost(int cost) {
        this.cost = cost;
    }

    public int getValue() {
        return value;
    }

    public void setValue(int value) {
        this.value = value;
    }

    public Node getDad() {
        return dad;
    }

    public void setDad(Node dad) {
        this.dad = dad;
    }

    @Override
    public String toString() {
        return "Node{" +
                "state=" + state +
                ", action=" + action +
                ", cost=" + cost +
                ", value=" + value +
                ", dad=" + dad +
                '}';
    }

}
