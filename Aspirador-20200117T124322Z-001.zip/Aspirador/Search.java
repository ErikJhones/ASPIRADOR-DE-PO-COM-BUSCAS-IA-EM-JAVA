package Aspirador;
import java.util.*;

public class Search {
	
	//metodo que faz busca em largura
	public List<Integer> largura(Problem problem1){
		
		System.out.println("Busca em Largura:");

        Node no = new Node(problem1.initialState, null, 0, 0, 0);// Iniciando o no com o estado inicial.
        List<Node> borda = new ArrayList<Node>(); //borda que vai ter os estados a serem verificados
        List<Integer> solucao = new ArrayList<Integer>();//lista que vai ter as acoes
        borda.add(no); //a borda recebe o estado do no raiz

        if(problem1.objectiveTest(no.getState())) {
        	System.out.println("O estado desse node eh o objetivo");
        	return null;
        }

        Node filho; // Ira receber o proximo estado.
        while(true) {//loop infinito

        	if(borda.isEmpty()) { //se borda ta vazia
        		System.out.println("\nfalha"); //retorne falha
        		break;

        	}else {//se nao ta vazia

        		no = borda.get(0); //passa o primeiro elem da borda pra no
        		borda.remove(0); //remove o elem da borda

        		if(problem1.objectiveTest(no.getState())) {//se o node eh o objetivo
        			solu(no, solucao);
        			return solucao; //retorna solucao

        		}else { //se nao
                    Collections.shuffle(problem1.getActions()); // Embaralha a lista de acoes
        			for(Integer i = 0; i<3;i++) {//itera as acoes.
        				System.out.println("Action "+problem1.getActions().get(i));//Mostra a acao que sera executada
        				System.out.println("Estado atual:");
        				printar(no.getState());

        				int[] novoEstado = problem1.successor(no.getState(), problem1.getActions().get(i));

        				if(novoEstado != null) {
        					System.out.println("Proximo estado:");

        					printar(novoEstado);
        					filho = new Node(novoEstado, no, problem1.getActions().get(i), custoTotalNode(no)+1, 0);
        					System.out.printf("\ncusto do caminho %d\n", filho.getCost());
        					borda.add(filho);

        				}

        			}
        			System.out.println("_______________________________________________");
        		}
        	}
        }

        return null;
    }//fim do metodo largura()
	
	public List<Integer> profundidade(Problem problem1){
		
			System.out.println("Busca em Profundidade:");
			List<Node> borda = new ArrayList<Node>(); //borda que vai ter os estados a serem verificados
			List<Integer> solucao = new ArrayList<Integer>();//lista que vai ter as acoes

	        Node no = new Node(problem1.initialState, null, 0, 0, 0);
	        borda.add(no); //a borda recebe o estado do no raiz
	        
	        if(problem1.objectiveTest(no.getState())) {
	        	System.out.println("O estado desse node eh o objetivo");
	        	return null;
	        }
	        
	        Node filho;
	        while(true) {//loop infinito
	        	
	        	if(borda.isEmpty()) { //se borda ta vazia
	        		System.out.println("\nfalha"); //retorne falha
	        		break;
	        		
	        	}else {//se nao ta vazia
	        		
	        		no = borda.get(0); //passa o primeiro elem da borda pra no
	        		borda.remove(0); //remove o elem da borda
	        		
	        		if(problem1.objectiveTest(no.getState())) {//se o no ï¿½ objetivo
	        			solu(no, solucao);
	        			return solucao; //retorna solucao
	        			
	        		}else { //se nao
	        			Collections.shuffle(problem1.getActions()); // Embaralha a lista de acoes
	        			for(Integer i = 0; i<3;i++) {//itera as aï¿½oes.
	        				System.out.println("Action "+problem1.getActions().get(i));
	        				System.out.println("Estado atual:");
	        				printar(no.getState());
	        				
	        				int[] novoEstado = problem1.successor(no.getState(), problem1.getActions().get(i));
	        				
	        				if(novoEstado != null) {
	        					System.out.println("Proximo estado:");
	        					
	        					printar(novoEstado);
	        					filho = new Node(novoEstado, no, problem1.getActions().get(i), custoTotalNode(no)+1, 0);
	        					borda.add(0,filho);
	        					
	        				}
	        				
	        			}
	        			System.out.println("_______________________________________________");
	        		}
	        	}
	        }
	        
	        return null;
	    }//fim do metodo Profundidade()
	
	public List<Integer> profundidadeVisitados(Problem problem1){
		
		System.out.println("Busca em Profundidade com Lista de Visitados:");
		List<Integer> solucao = new ArrayList<Integer>();//lista que vai ter as aï¿½oes
		List<Node> borda = new ArrayList<Node>(); //borda que vai ter os estados a serem verificados
		List<Node> visitados = new ArrayList<Node>(); //Lista criada para armazenar nos ja visitados
		
        Node no = new Node(problem1.initialState, null, 0, 0, 0);
        borda.add(no); //a borda recebe o estado do no raiz
        
        if(problem1.objectiveTest(no.getState())) {
        	System.out.println("O estado desse node eh o objetivo");
        	return null;
        }
        
        
        Node filho;
        while(true) {//loop infinito
        	
        	if(borda.isEmpty()) { //se borda ta vazia
        		System.out.println("\nfalha"); //retorne falha
        		break;
        		
        	}else {//se nao ta vazia
        		
        		no = borda.get(0); //passa o primeiro elem da borda pra no
        		borda.remove(0); //remove o elem da borda
        		visitados.add(0,no);
        		
        		if(problem1.objectiveTest(no.getState())) {//se o no ï¿½ objetivo
        			solu(no, solucao);
        			return solucao; //retorna solucao
        			
        		}else { //se nao
        			
        			for(Integer i = 1; i<=3;i++) {//itera as aï¿½oes.
        				
        				System.out.println("Action "+i);
        				System.out.println("Estado atual:");
        				printar(no.getState());
        				
        				int[] novoEstado = problem1.successor(no.getState(), i);
        				
        				if(novoEstado != null) {
        					System.out.println("Proximo estado:");
        					printar(novoEstado);
        					filho = new Node(novoEstado, no, i, no.getCost(), 0);
        					if(visitado(visitados, filho)) {
        						borda.add(0, filho); //Adiciona todo proximo estado no inicio da lista
        					}
        				}
        				
        			}
        			System.out.println("_______________________________________________");
        		}
        	}
        }
        
        return null;
    }//fim do metodo profundidadeVisitados()
	
	public List<Integer> profundidadeLimitada(Problem problem1, int limite){
			
			System.out.println("Busca em Profundidade Limitada:");
			List<Integer> solucao = new ArrayList<Integer>();//lista que vai ter as aï¿½oes
			List<Node> borda = new ArrayList<Node>(); //borda que vai ter os estados a serem verificados
	        Node no = new Node(problem1.initialState, null, 0, 0, 0);
	        borda.add(no); //a borda recebe o estado do no raiz
	        
	        if(problem1.objectiveTest(no.getState())) {
	        	System.out.println("O estado desse node eh o objetivo");
	        	return null;
	        }
	        
	        
	        Node filho;
	        int variavel = 0;
	        while(variavel < limite) {//loop
	        	
	        	System.out.println("Nivel "+variavel);
	        	System.out.println("##############");
	        	if(borda.isEmpty()) { //se borda ta vazia
	        		System.out.println("\nfalha"); //retorne falha
	        		break;
	        		
	        	}else {//se nao ta vazia
	        		
	        		no = borda.get(0); //passa o primeiro elem da borda pra no
	        		borda.remove(0); //remove o elem da borda
	        		
	        		if(problem1.objectiveTest(no.getState())) {//se o no ï¿½ objetivo
	        			solu(no, solucao);
	        			return solucao; //retorna solucao
	        			
	        		}else { //se nao
	        			
	        			for(Integer i = 1; i<=3;i++) {//itera as aï¿½oes.
	        				
	        				System.out.println("Action "+i);
	        				System.out.println("Estado atual:");
	        				printar(no.getState());
	        				
	        				int[] novoEstado = problem1.successor(no.getState(), i);
	        				
	        				if(novoEstado != null) {
	        					System.out.println("Proximo estado:");
	        					printar(novoEstado);
	        					filho = new Node(novoEstado, no, i, no.getCost(), 0);
	        					borda.add(0, filho); //Adiciona todo proximo estado no inicio da lista
	        				}
	        				
	        			}
	        			System.out.println("_______________________________________________");
	        		}
	        	}
	        	variavel++;
	        }//fim do laï¿½o while
	        
	        System.out.println("Nao achou solucao");
	        return null;
	}//fim do metodo profundidadeLimitada()
	
	//metodo de busca profundidade com aprofundamento iterativo
	public List<Integer> profundidadeIterativa(Problem problem1){
		int variavel = 0;
		List<Integer> resultado = new ArrayList<Integer>();
		
		while(true) {//loop infinito
			
			resultado = profundidadeLimitada(problem1, variavel); // Chama o metodo Limitado
			if(resultado != null) {
				return resultado;
			}
			variavel++;
		}
	}//fim do metodo profundidadeIterativo()
	
	//Metodo de busca de custo uniforme
	public List<Integer> custoUniforme(Problem problem1){
		System.out.println("Busca de Custo Uniforme:");
        Node no = new Node(problem1.initialState, null, 0, 0, 0);
        List<Node> borda = new ArrayList<Node>(); //borda que vai ter os estados a serem verificados
        List<Integer> solucao = new ArrayList<Integer>();//lista que vai ter as aï¿½oes
        List<Node> visitados = new ArrayList<Node>();
        
        borda.add(no); //a borda recebe o estado do no raiz
        
        Node filho;
        while(true) {//loop infinito
        	
        	if(borda.isEmpty()) { //se borda ta vazia
        		System.out.println("\nfalha"); //retorne falha
        		break;
        		
        	}else {//se nao ta vazia
        		ordenaBordaCusto(borda); //Ordena a borda com relaÃ§ao ao custo de cada estado.
        		no = borda.get(0); //passa o primeiro elem da borda pra no
        		visitados.add(no); //Adiciona na lista de visitados
        		borda.remove(0); //remove o elem da borda
        		
        		if(problem1.objectiveTest(no.getState())) {//se o no ï¿½ objetivo
        			solu(no, solucao);
        			return solucao; //retorna solucao
        			
        		}else { //se nao 
        			for(Integer i = 1; i<=3;i++) {//itera as acoes.
        				
        				System.out.println("Action "+i);
        				System.out.println("Estado atual:");
        				printar(no.getState());
        				
        				int[] novoEstado = problem1.successor(no.getState(), i);
        				
        				if(novoEstado != null) {
        					System.out.println("Proximo estado:");
        					printar(novoEstado);
        					filho = new Node(novoEstado, no, problem1.getActions().get(i-1), custoTotalNode(no)+1, 0);
        					System.out.printf("\ncusto total %d\n", filho.getCost());
        					if(visitado(visitados, filho)) {
        						borda.add(filho);
        					}

        				}
        				
        			}
        			System.out.println("_______________________________________________");
        		}
        	}
        }
        
        return null;
	} //Fim do metodo de busca de custoUniforme()

	//Metodo de busca bidirecional
	public List<Integer> buscaBidirecional(Problem problem1){
		int cimaBaixo, baixoCima;
		List<Integer> solucaoGeral = new ArrayList<Integer>();

		List<Integer> solucaoBC = new ArrayList<Integer>(); // Tera as solucoes baixo cima
		List<Integer> solucaoCB = new ArrayList<Integer>(); // Tera as solucoes cima baixo

		List<Node> bordaCB = new ArrayList<Node>(); // Tera os estados cima baixo
		List<Node> bordaBC1 = new ArrayList<Node>(); // Tera os estados baixo cima para o objetivo 1
		List<Node> bordaBC2 = new ArrayList<Node>(); // Tera os estados baixo cima para o objetivo 2

		List<Node> visitadoCB = new ArrayList<Node>(); // Tera os estados visitados cima baixo
		List<Node> visitadoBC = new ArrayList<Node>(); // Tera os estados visitados baixo cima

		Scanner ler02 = new Scanner(System.in);
		Scanner ler01 = new Scanner(System.in);
		Objectives stateBC = new Objectives(); // Instanciando os objetivos.

		Node noCB = new Node(problem1.initialState, null, 0, 0, 0); // Iniciando o node com o estado inicial
		Node noBC1 = new Node(stateBC.getObjectiveState1(), null, 0, 0, 0); // Guarda o primeiro objetivo.
		Node noBC2 = new Node(stateBC.getObjectiveState2(), null, 0, 0, 0);// Guarda o segundo objetivo.
		Node filhoCB, filhoBC1, filhoBC2; // Nodes sucessores.
		
		System.out.println("Busca em Bidirecional:");
		System.out.println("Escolha o metodo que irÃ¡ realizar a busca de cima para baixo: ");
		System.out.println("1 - Metodo De Busca Em Largura. \n 2 - Metodo De Busca Em Profundidade.");
		cimaBaixo = ler01.nextInt();
		
		System.out.println("Escolha o metodo que irÃ¡ realizar a busca de baixo para cima: ");
		System.out.println("1 - Metodo De Busca Em Largura. \n 2 - Metodo De Busca Em Profundidade.");
		baixoCima = ler02.nextInt();

		//Adicionando os nos iniciais na borda
		bordaCB.add(noCB);
		bordaBC1.add(noBC1);
		bordaBC2.add(noBC2);
		
		while (true){ //Verifica se esta as buscas se encontraram em algum ponto
		
			if(bordaBC1.isEmpty() || bordaCB.isEmpty() || bordaBC2.isEmpty()){
				System.out.println("Falhou!!!");
				return null;
			} else {
				if(!(visitado(visitadoCB, noBC1)) || !(visitado(visitadoCB, noBC2)) || !(visitado(visitadoBC, noCB))) {//verifica se esta nos visitados

					Node auxBC = noSolucao(noCB, visitadoBC);//pega no se estiver na lista de visitados de baixo pra cima
					Node auxCB = noSolucao(noBC1, visitadoCB);//pega no se estiver na lista de visitados de cima pra baixo

					if(auxCB == null){//se o estado de convergencia nao estiver na arvore de BC1, entao olha na arvore de BC2
						auxCB = noSolucao(noBC2, visitadoCB);
					}

					//se os nós atuais tiverem seus estados diferentes e eles estiverem na lista de visitados um do outro.
					//houve uma dupla convergencia de estados
					if(auxBC != null && auxCB != null){
						if(!(Arrays.equals(auxBC.getState(), auxCB.getState()))){ //se os estados desses aux´s forem diferentes.
							auxBC = noSolucao(auxCB, visitadoBC); //seta auxBC com o no de visitadoBC que tem o mesmo estado de AuxCB
						}
					}
					//Um dos nodes pode vir nulo
					if(auxCB == null && auxBC != null) {
						auxCB = noSolucao(noCB, visitadoCB);
					}
					else if(auxBC == null && auxCB != null) {
						auxBC = noSolucao(noBC1, visitadoBC);
					}
					
					System.out.printf("\nCB \n");
					printar(auxCB.getState());
					
					System.out.printf("\nBC\n");
					printar(auxBC.getState());
					System.out.println("Solução cima pra baixo");
					solu(auxCB, solucaoCB);
					System.out.println("solução baixo pra cima");
					solu(auxBC, solucaoBC);
					
					solucaoGeral.addAll(solucaoCB);
					System.out.println("-------------------------------------");
					solucaoGeral.addAll(solucaoBC);
					return solucaoGeral;
				}else{
					noCB = bordaCB.get(0);
					noBC1 = bordaBC1.get(0);
					noBC2 = bordaBC2.get(0);

					visitadoCB.add(noCB);
					visitadoBC.add(noBC1);
					visitadoBC.add(noBC2);

					bordaCB.remove(0);
					bordaBC1.remove(0);
					bordaBC2.remove(0);
					
					if (cimaBaixo == 1) { //Busca em largura selecionado caso entre nesse IF
						System.out.println("Cima baixo:");
						Collections.shuffle(problem1.getActions());
						for(Integer i = 0; i<3;i++) {//itera as aï¿½oes.
							System.out.println("Estado atual:");
							System.out.println("Action "+problem1.getActions().get(i));
							printar(noCB.getState());

							int[] novoEstado = problem1.successor(noCB.getState(), problem1.getActions().get(i));

							if(novoEstado != null) {
								System.out.println("Proximo estado:");

								printar(novoEstado);
								filhoCB = new Node(novoEstado, noCB, problem1.getActions().get(i), 0, 0);
								bordaCB.add(filhoCB);
							}

						}
						System.out.println("_______________________________________________");
					} else {
						System.out.println("Cima baixo:");
						Collections.shuffle(problem1.getActions());
						for(Integer i = 0; i<3;i++) {//itera as aï¿½oes.
							System.out.println("Estado atual:");
							System.out.println("Action "+problem1.getActions().get(i));
							printar(noCB.getState());

							int[] novoEstado = problem1.successor(noCB.getState(), problem1.getActions().get(i));

							if(novoEstado != null) {
								System.out.println("Proximo estado:");
								printar(novoEstado);
								filhoCB = new Node(novoEstado, noCB, problem1.getActions().get(i), 0, 0);
								bordaCB.add(0, filhoCB);
							}
						}
						System.out.println("_______________________________________________");
					}

					if (baixoCima == 1){
						System.out.println("Baixo cima:");
						Collections.shuffle(problem1.getActions());
						for(Integer i = 0; i<3;i++) {//itera as aï¿½oes.
							System.out.println("Estado atual:");
							System.out.println("Action "+problem1.getActions().get(i));
							printar(noBC1.getState());
							printar(noBC2.getState());

							int[] novoEstado1 = problem1.successor2(noBC1.getState(), problem1.getActions().get(i));
							int[] novoEstado2 = problem1.successor2(noBC2.getState(), problem1.getActions().get(i));

							if(novoEstado1 != null) {
								System.out.println("Proximo estado:");

								printar(novoEstado1);
								filhoBC1 = new Node(novoEstado1, noBC1, problem1.getActions().get(i), 0, 0);
								bordaBC1.add(filhoBC1);
							}

							if(novoEstado2 != null) {
								System.out.println("Proximo estado:");

								printar(novoEstado2);
								filhoBC2 = new Node(novoEstado2, noBC2, problem1.getActions().get(i),0, 0);
								bordaBC2.add(filhoBC2);
							}
						}
						System.out.println("_______________________________________________");
					}else {
						System.out.println("Baixo cima:");
						Collections.shuffle(problem1.getActions());
						for(Integer i = 0; i<3;i++) {//itera as aï¿½oes.
							System.out.println("Estado atual:");
							System.out.println("Action "+problem1.getActions().get(i));
							printar(noBC1.getState());
							printar(noBC2.getState());

							int[] novoEstado1 = problem1.successor2(noBC1.getState(), problem1.getActions().get(i));
							int[] novoEstado2 = problem1.successor2(noBC2.getState(), problem1.getActions().get(i));

							if(novoEstado1 != null) {
								System.out.println("Proximo estado:");

								printar(novoEstado1);
								filhoBC1 = new Node(novoEstado1, noBC1, problem1.getActions().get(i), 0, 0);
								bordaBC1.add(filhoBC1);
							}

							if(novoEstado2 != null) {
								System.out.println("Proximo estado:");

								printar(novoEstado2);
								filhoBC2 = new Node(novoEstado2, noBC2, problem1.getActions().get(i),0, 0);
								bordaBC2.add(0,filhoBC2);
							}
						}
						System.out.println("_______________________________________________");
					}
				}
			}
		}
        //return null;
	} //Fim do metodo de buscaBidirecional()
	
	//Metodo da buscaGulosa()
	public List<Integer> buscaGulosa(Problem problem1){
		System.out.println("Busca Gulosa Pela Melhor Escolha:");
        Node no = new Node(problem1.initialState, null, 0, 0, 0);
        List<Node> borda = new ArrayList<Node>(); //borda que vai ter os estados a serem verificados
        List<Integer> solucao = new ArrayList<Integer>();//lista que vai ter as aï¿½oes
        List<Node> visitados = new ArrayList<Node>();
        
        borda.add(no); //a borda recebe o estado do no raiz
        
        Node filho;
        while(true) {//loop infinito
        	
        	if(borda.isEmpty()) { //se borda ta vazia
        		System.out.println("\nfalha"); //retorne falha
        		break;
        		
        	}else {//se nao ta vazia
        		ordenaBordaCusto(borda); //Ordena a borda com relaÃ§ao ao custo de cada estado.
        		no = borda.get(0); //passa o primeiro elem da borda pra no
        		visitados.add(no); //Adiciona na lista de visitados
        		borda.remove(0); //remove o elem da borda
        		
        		if(problem1.objectiveTest(no.getState())) {//se o no ï¿½ objetivo
        			solu(no, solucao);
        			return solucao; //retorna solucao
        			
        		}else { //se nao
        			for(Integer i = 1; i<=3;i++) {//itera as acoes.
        				
        				System.out.println("Action "+i);
        				System.out.println("Estado atual:");
        				printar(no.getState());
        				
        				int[] novoEstado = problem1.successor(no.getState(), i);
        				
        				if(novoEstado != null) {
        					System.out.println("Proximo estado:");
        					printar(novoEstado);

        					filho = new Node(novoEstado, no, problem1.getActions().get(i-1), problem1.getHeuristica(problem1.getMatriz(novoEstado)), 0);
        					System.out.printf("\ncusto total %d\n", filho.getCost());
        					if(visitado(visitados, filho)) {
        						borda.add(filho);
        					}

        				}

        			}
        			System.out.println("_______________________________________________");
        		}
        	}
        }
        
        return null;
	} //Fim do metodo de buscaGulosa()

	//Metodo da aEstrela()
	public List<Integer> aEstrela(Problem problem1){
		System.out.println("Busca A*:");
		Node no = new Node(problem1.initialState, null, 0, 0, 0);
		List<Node> borda = new ArrayList<Node>(); //borda que vai ter os estados a serem verificados
		List<Integer> solucao = new ArrayList<Integer>();//lista que vai ter as aï¿½oes
		List<Node> visitados = new ArrayList<Node>();

		borda.add(no); //a borda recebe o estado do no raiz

		Node filho;
		while(true) {//loop infinito

			if(borda.isEmpty()) { //se borda ta vazia
				System.out.println("\nfalha"); //retorne falha
				break;

			}else {//se nao ta vazia
				ordenaBordaValue(borda); //Ordena a borda com relaÃ§ao ao custo de cada estado.
				no = borda.get(0); //passa o primeiro elem da borda pra no
				visitados.add(no); //Adiciona na lista de visitados
				borda.remove(0); //remove o elem da borda

				if(problem1.objectiveTest(no.getState())) {//se o no ï¿½ objetivo
					solu(no, solucao);
					return solucao; //retorna solucao

				}else { //se nao
					for(Integer i = 1; i<=3;i++) {//itera as acoes.

						System.out.println("Action "+i);
						System.out.println("Estado atual:");
						printar(no.getState());

						int[] novoEstado = problem1.successor(no.getState(), i);

						if(novoEstado != null) {
							System.out.println("Proximo estado:");
							printar(novoEstado);

							filho = new Node(novoEstado, no, problem1.getActions().get(i-1), problem1.getHeuristica(problem1.getMatriz(novoEstado)), problem1.getHeuristica(problem1.getMatriz(novoEstado))+(custoTotalNode(no)+1));
							System.out.printf("\ncusto total %d\n", filho.getValue());
							if(visitado(visitados, filho)) {
								borda.add(filho);
							}

						}

					}
					System.out.println("_______________________________________________");
				}
			}
		}

		return null;
	} //Fim do metodo aEstrela()


	//metodo que gera o vetor solucao de acoes da folha ate a raiz da arvore 
	private void solu(Node filho, List<Integer> solucao) {
		Node aux = filho;
		while(aux.getAction() != 0) {
			System.out.printf("-----Proximo estado com acao %d:\n",aux.getAction());
			printar(aux.getState());
			System.out.println();
			solucao.add(aux.getAction());
			aux = aux.getDad(); //pega o pai do node filho
		}
		System.out.println("-----Estado inicial:");//Printa a raiz
		printar(aux.getState());
		System.out.println();
	}//fim do metodo solu
	
	private void printar(int[] vetor) {
		for(int i=0;i<vetor.length;i++) {
			System.out.printf("\t%d", vetor[i]);
		}
		System.out.println();
	}

	//Metodo que retorna o custo de um no folha ate a raiz
    private int custoTotalNode(Node no){
        int cost = 0;
        if (no.getDad() != null){
            cost = no.getCost();
            return cost;
        }
        return cost;
    }
	
	//metodo que verifica se novo estado esta na lista de visitados
	private boolean visitado(List<Node> visit, Node no) {
		for(int x=0;x<visit.size();x++) {
			if(Arrays.equals(no.getState(), visit.get(x).getState())) {
				return false;
			}
		}
		return true;
	}
	
	//Metodo para ordernar a borda por ordem crescente de Custo (Utilizado em custo Uniforme e na Gulosa)
	private void ordenaBordaCusto(List<Node> borda) {
		Node aux;
        for (int i = 0; i < borda.size(); i++){
            for (int j = 0; j < borda.size(); j++){
                if (borda.get(i).getCost() <= borda.get(j).getCost()){
                	aux = borda.get(i);
                	borda.set(i, borda.get(j));
                	borda.set(j, aux);
                }
            }
        }
	}

	//Metodo para ordernar a borda por ordem crescente de Custo (Utilizado em aEstrela)
	private void ordenaBordaValue(List<Node> borda) {
		Node aux;
		for (int i = 0; i < borda.size(); i++){
			for (int j = 0; j < borda.size(); j++){
				if (borda.get(i).getValue() <= borda.get(j).getValue()){
					aux = borda.get(i);
					borda.set(i, borda.get(j));
					borda.set(j, aux);
				}
			}
		}
	}
	
    //metodo que retorna o no que esta em ambas as arvores de busca bidirecional
    private Node noSolucao(Node no, List<Node> solucao) {
    	for(int i=0; i<solucao.size(); i++) {
    		if(Arrays.equals(no.getState(), solucao.get(i).getState())) {
    			return solucao.get(i);
    		}
    	}
    	
    	return null;
    }
	
}		