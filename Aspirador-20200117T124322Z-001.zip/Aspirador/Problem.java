package Aspirador;

import java.util.Arrays;
import java.util.List;
import java.util.HashMap;
import java.util.Map;

public class Problem {
	// Acoes que seram executadas pelo aspirador.
	//  # Acao 1 - Vai para a esquerda
	//  # Acao 2 - Vai para a direita
	//  # Acao 3 - Aspira
	
  int initialState[] = new int[3];
  int cost = 0;
  private List<Integer> actions; // Lista que ira guardar as acoes que seram executadas.
  private Map<int[], Integer> heuristica; // Hash map para guardar a heuristica.
  Objectives objective = new Objectives(); // Instanciando um objeto do tipo objetivo.

  //Matriz com todos os estados possiveis do aspirador.
  private int matriz[][] = {{1,0,0}, {1,1,0},
		  					{1,0,1}, {1,1,1},
		  					{2,0,0}, {2,0,1},
		  					{2,1,0}, {2,1,1}};

  //Metodo heuristica que vai informar a quantidade de passos de determinado estado ate o objetivo de acordo com a matriz de estados.
  private void heuristica() {
      heuristica.put(matriz[0], 0);
      heuristica.put(matriz[1], 1);
      heuristica.put(matriz[2], 2);
      heuristica.put(matriz[3], 3);
      heuristica.put(matriz[4], 0);
      heuristica.put(matriz[5], 1);
      heuristica.put(matriz[6], 2);
      heuristica.put(matriz[7], 3);
  }

  
  public Problem(int estadoInicial) { // Construtor para iniciar o problema a partir de um estado inicial passado.
	  actions = Arrays.asList(1,2,3); // Adicionando as acoes possiveis para a lista de acoes.
	  heuristica = new HashMap<int[], Integer>(); // Instanciando o objeto heuristica.
	  heuristica();// Chamando o metodo heuristica
	  this.initialState = matriz[estadoInicial]; // Setando o estado inicial de acordo com a matriz de estados.
  }

//  Verifica se o estato passado eh algum dos dois objetivos
  public boolean objectiveTest(int[] state){
      if (Arrays.equals(state, objective.getObjectiveState1()) || Arrays.equals(state, objective.getObjectiveState2())){
          return true;
      } else {
    	  return false;
      }
  }

//  Recebe o estado atual e uma acao e retorna o proximo estado.
  public int[] successor(int[] state, Integer action){
	  int [] state2 = state.clone(); //copia o vetor de estado em estado
	  
      if (state[0] == 1 && action == 2){// Verifica se esta na sala 1 e a acao e ir para a direita
          state2[0] = 2; // Muda o estado passado da sala 1 para a sala 2
          cost+=1; // Adiciona o custo da acao
          return state2; // retorna o estado.
      }

      else if (state[0] == 2 && action == 1){// Verifica se esta na sala 2 e a acao e ir para a esquerda
          state2[0] = 1;// Muda o estado passado da sala 2 para a sala 1
          cost+=1;// Adiciona o custo da acao
          return state2;// retorna o estado.
      }

      else if (state[0] == 2 && action == 3 && state[2] == 1){// Verifica se esta na sala 2 e a acao de limpar e verifica se a sala 2 esta suja
          state2[2] = 0; // Limpa a sala 2
          cost+=1;// Adiciona o custo da acao
          return state2;// retorna o estado.
      }

      else if (state[0] == 1 && action == 3 && state[1] == 1){// Verifica se esta na sala 1 e a acao de limpar e verifica se a sala 1 esta suja
          state2[1] = 0; // Limpa a sala 1
          cost+=1;// Adiciona o custo da acao
          return state2;// retorna o estado.
      }

      else { // Se nenhuma das opções retorna null.

    	  return null;
      }
  }

    //  funcao sucessora da busca baixo pra cima para a busca bidirecional.
    // Diferenca da funcao sucessora padrao e que ela meio que "suja" a sala ao inves de limpar.
    public int[] successor2(int[] state, Integer action){
        int [] state2 = state.clone(); //copia o vetor de estado em estado

        if (state[0] == 1 && action == 2){
            state2[0] = 2;
            cost+=1;
            return state2;
        }

        else if (state[0] == 2 && action == 1){
            state2[0] = 1;
            cost+=1;
            return state2;
        }

        else if (state[0] == 2 && action == 3 && state[2] == 0){

            state2[2] = 1;
            cost+=1;
            return state2;
        }

        else if (state[0] == 1 && action == 3 && state[1] == 0){

            state2[1] = 1;
            cost+=1;
            return state2;
        }

        else {

            return null;
        }
    }

  
  public List<Integer> getActions(){
	  return actions;
  } // Para pegar as acoes executadas.

  //metodo que retorna a heuristica com base no estado atual
  public int getHeuristica(int[] state) {
	  return heuristica.get(state);
  }

  //metodo que retorna o objeto que vai ser usado na heuristica
  public int[] getMatriz(int[] vetor){
      int lepra;
      for(int i=0; i < matriz.length; i++){
          lepra = 1;
          for(int j=0; j<3; j++) {
              if (vetor[j] == matriz[i][j]) {
              }
              else {
                  lepra *= 0;
              }
          }
          if(lepra == 1) {
              return matriz[i];
          }
      }
      return null;
  }

}
